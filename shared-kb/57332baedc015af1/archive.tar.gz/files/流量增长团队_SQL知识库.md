# 流量增长团队(短带业务) SQL数据知识库

这份文档是基于“流量增长团队-知识库（初稿，原始素材）”提炼的领域知识库。主要目的是为了帮助 AI 和数据/研发人员快速理解【流量增长团队】业务场景、表结构、核心指标逻辑以及常用 SQL 写法，以便根据简短的自然语言需求准确编写出目标 SQL。

---

## 一、 核心业务概念及术语

### 1. 核心业务：短带业务
“短带长”业务：指 UP 主发布二创/种草类短视频，在播放页通过**组件**挂载对应的长视频或付费内容，引导用户点击进入完成“观看”、“付费”、“曝光”等转化行为。
**业务闭环**：内容生产 -> 内容挂载 -> 内容组件消费（曝光/点击） -> 转化归因（订单生成/广告曝光）。

### 2. 子业务场景
- **漫剧小程序/短剧小程序**：主要包括 IAA（看广告免费解锁）和 IAP（直接付费购买）两种模式。
- **充电**：包括自定义充电、包月充电、单片付费三种。用户可通过观看广告获取观看机会（IAA），或直接充电解锁（IAP）。
- **OGV/课堂**：引流用户开通大会员或直接付费。
- **小说小程序/收藏集**：导向小说或其他内容的阅读与抽取。

### 3. 组件形式及引流方式
短带业务的挂载组件/资源位包含：
- **story 锚点**、**蓝链（评论区）**、**合集**、**关联视频**、**空间页**、**框下**。
- 引流方式字段辨识：
  - 天马直接分发：`track = 'tianma'` 且从天马推荐等渠道进入。
  - story直接分发：`track = 'story'`。
  - 相关推荐分发：`spmid` 包含 `'united.player-video-detail'`。

---

## 二、 核心数据模型与 Hive 表结构

在进行数据查询时，优先使用以下核心表。

### 1. 核心事实表（行为与转化）

| 表名 (Table Name) | 业务描述 | 核心粒度 / 关键字段 |
| :--- | :--- | :--- |
| **`b_dim.dim_flow_short_x_show_click_hr`** | 夯短带x**曝光点击**行为事实表 | 引流组件单次曝光/点击。需配合业务类型筛选。 |
| **`b_dws.dws_socl_short2x_order_source_detail_info_1d_d`** | 夯短带x**收入转化归因宽表** | 订单id。涵盖各项业务转化的 IAP 宽/窄口径订单金额。**只含归因给种草稿件的订单，非全量收入**。覆盖充电/OGV/短剧小程序/课堂/收藏集。 |
| **`b_dwb.dwb_socl_short2x_playletminiapp_user_behavior_detail_l_d`** | 短剧小程序正片和**广告曝光**明细表 | 小程序日志的单次曝光、广告转化记录（含广告 `gmv` 等字段）。`goto='av'`=正片单集曝光，`goto='ad'`=广告曝光。 |
| **`b_dwb.dwb_socl_short2x_playletminiapp_funnel_i_d`** | 短剧小程序**漏斗**表 | 小程序跳转展示/点击、广告展示(`ad_show_pv`)、播完、直接/间接归因(`ad_gmv_direct`, `ad_gmv_indirect`)。⚠️ `ad_gmv_indirect` **不可直接 SUM**，需按 `from_avid` 汇总取 `MAX`。 |
| **`b_dwb.dwb_trad_ord_elec_order_detail_info_i_d`** | 全部充电业务订单信息表(充电**订单宽表**) | 全量充电订单首选表。`biz_id=9999` 自定义充电、`biz_id=10000` 单片付费、`biz_id=10001` 包月充电。 |
| **`bili_sycpb.dwd_flow_req_pfmc_charge_comic_ad_attribution_l_d`** | 相关广告渠道/天马/Story等**充电 IAA 收入表** | 各类IAA归因的底层广告请求收入表（商业侧提供的自然归因结果）。 |
| **`iceberg_bdp.dwb_flow_abtest_group_split_l_1d_d`** | AB 实验分流结果表 | 用于获取实验组 (`expr_id`, `group_id`, `splited_flow_id` 即 `mid`)，**仅适用于非算法实验**。 |

### 2. 核心维度表

| 表名 (Table Name) | 业务描述 | 核心字段说明 |
| :--- | :--- | :--- |
| **`b_dim.dim_ctnt_arch_basic_short_x_jump_content_view_a_hr`** | 夯短带x**内容维表** | 种草稿件id (`avid/from_avid`)、业务类型(`business_type`)、跳转形式(`jump_type`)、跳转目标(`item_id`)。 |
| **`b_ods.ods_db2824_t_archive_a_hr`** | **B站大仓稿件底层表** | 最新稿件属性，可解析 `archive_config`。`$.ad_unlock=true`表示授权**广告解锁**。 |
| **`b_dim.dim_ctnt_arch_business_tag_info_d`** | **稿件业务标签属性表** | 包含 `is_charging_pay=1` (是否充电付费), `up_id` (UP主), `up_fans`等。 |
| **`b_dim.dim_socl_short2x_open_mallapp_mini_app_cat_d`** | 小程序维表 | 记录各项小程序信息及分类等。 |
| **`bi_ogv.dim_ai_donghua_up_list`** / `_supple` | **UP主白名单维表** | 例如**动画种草**等业务名单。 `dim_ctnt_arch_business_tag_info_d` 也存部分UP。 |
| **`b_dim.dim_socl_elec_basic_up_info`** | UP行业与基本属性表 | 可用于UP行业归属判断。 |

---

## 三、 核心归因逻辑（Attribution Logic）与策略

AI 自动写 SQL 时，注意识别用户提到的**归因（直接/间接归因）**口径：

1. **直接归因**：
   - 依赖上报埋点的私参。如广告曝光埋点参数 `reportExtra` 带有 `from_avid`。
   - 这部分归因关联到的稿件，收益体现为“直接收益”（如短剧小程序的 `ad_gmv_direct`）。
2. **间接归因**：
   - 如果私参没有直接指定种草视频 `from_avid`，但上报了长视频卡片 `episode_id`，利用该 ID 去匹配用户最近一次通过该 `episode_id` 观看的种草视频。
   - 体现为间接收益（如 `ad_gmv_indirect`）。
3. **窄口径(Narrow) 与 宽口径(Broad)**：
   - 窄口径（充电 IAP）：三链路归因（A 直接跳转 → B 空间页 → C 兜底），需要组件点击行为验证。专用表：`b_dwb.dwb_socl_short2x_charge_order_play_source_narrow_detail_i_d`
   - 宽口径（充电 IAP）：不要求组件点击验证，取距离付费视频观看最近的来源视频。专用表：`b_dwb.dwb_socl_short2x_charge_order_play_source_broad_detail_i_d`
   - 两个口径均在 `b_dws.dws_socl_short2x_order_source_detail_info_1d_d` 中可用 `attribution_type` 字段区分。

---

## 四、 常见分析与 SQL 指南 (Examples)

下面列举几个日常最常见的查询模板，遇到类似需求时直接参考这些范本套用：

### 1. 漫剧/短剧原生 IAA 小程序收入（含分渠道）
**业务指标**：获取小程序的当日总播放次数及带来的总收入（把GMV除以100,000转换为元）。
```sql
SELECT
  log_date,
  sum(case when goto = 'av' then vv END) as vv,
  sum(ad_gmv)/100000 as gmv_yuan
FROM b_dwb.dwb_socl_short2x_playletminiapp_user_behavior_detail_l_d
WHERE log_date BETWEEN '20260101' AND '<%=log_date%>'
  AND app_name = '漫剧'
GROUP BY 1
ORDER BY 1 DESC;
```

**区分分发来源（天马/蓝链等）**：
```sql
SELECT
  log_date,
  CASE
    when sourcefrom in ('100101','100201') then '蓝链+story'
    when sourcefrom = '101001' then '天马'
    else '其他' 
  END as source_from_type,
  sum(ad_gmv)/100000 as gmv_yuan
FROM b_dwb.dwb_socl_short2x_playletminiapp_user_behavior_detail_l_d
WHERE log_date = '<%=log_date%>' AND app_name = '漫剧'
GROUP BY 1, 2;
```

### 2. 漫剧原生 IAA 授权稿件数统计
**业务逻辑**：从稿件底层表获取 `archive_config` 配置，包含 `"$.ad_unlock"='true'` 认为开启了广告解锁的授权。
```sql
-- 统计当日开启广告解锁功能的非重复稿件数
SELECT count(distinct aid) as avid_cnt
FROM b_ods.ods_db2824_t_archive_a_hr
WHERE log_date = '<%=log_date%>' 
  AND log_hour = 23
  AND get_json_object(archive_config,'$.ad_unlock') = 'true';
```

**过去7天作者/UP主的带货/授权明细**：
```sql
with t1 as (
  -- 提取授权解锁的稿件
  SELECT DISTINCT aid
  FROM b_ods.ods_db2824_t_archive_a_hr
  WHERE log_date = '<%=log_date%>'
    AND log_hour = 23
    AND get_json_object(archive_config, '$.ad_unlock') = 'true'
),
t_gmv as (
  -- 计算UP主近30天的带货GMV
  SELECT up_id, sum(order_real_amount/100) as last_30_gmv
  FROM b_dwb.dwb_trad_ord_elec_order_detail_info_i_d    
  WHERE log_date between '<%=log_date-30%>' and '<%=log_date%>'
  GROUP BY 1
)
SELECT
  t2.up_id,
  t2.uname,
  t2.up_fans,
  t_gmv.last_30_gmv,
  count(DISTINCT t1.aid) as shouquan_num
FROM t1 
LEFT JOIN b_dim.dim_ctnt_arch_business_tag_info_d t2 ON t1.aid = t2.avid AND t2.log_date = '<%=log_date%>'
LEFT JOIN t_gmv ON t2.up_id = t_gmv.up_id
WHERE date(t2.first_pub_time) >= date_sub(date('<%=log_date%>'), 7)
GROUP BY 1,2,3,4;
```

### 3. 短带漏斗表（曝光、点击与直接/间接归因）
**业务逻辑**：使用 `dwb_socl_short2x_playletminiapp_funnel_i_d` 获取展示、点击及直接间接转化金额。ECPM常按 1000 展示的收入折算。
```sql
SELECT
  log_date,
  sum(jump_show_pv) as jump_show_pv,
  sum(jump_click_pv) as jump_click_pv,
  sum(ad_show_pv) as ad_show_pv,
  sum(ad_end_pv) as ad_end_pv,
  sum(ad_gmv_direct) as ad_gmv_direct,
  sum(ad_gmv_indirect) as ad_gmv_indirect,
  round(sum(ad_gmv_direct)/100000, 2) as ad_gmv_direct_yuan,
  round(sum(ad_gmv_indirect)/100000, 2) as ad_gmv_indirect_yuan,
  round((sum(ad_gmv_direct) + sum(ad_gmv_indirect))/100000 / nullif(sum(ad_show_pv),0) * 1000, 2) as ecpm
FROM b_dwb.dwb_socl_short2x_playletminiapp_funnel_i_d
WHERE log_date >= '20250317'
  AND to_appid = 'biliaf83c642b5ce025e'  -- 短剧/漫剧小程序的appid
GROUP BY log_date;
```

### 4. 实验分流（AB Test）获取实验人群

> 完整的实验分析流程和 SQL 模板见 → [实验分析框架](实验分析框架.md)

核心分流表（非算法实验）：

```sql
SELECT DISTINCT splited_flow_id AS mid, group_id
FROM iceberg_bdp.dwb_flow_abtest_group_split_l_1d_d
WHERE log_date BETWEEN '<%=start_date%>' AND '<%=end_date%>'
  AND expr_id = '<实验ID>'
  AND group_id IN ('<实验组ID>', '<对照组ID>')
```

---

## 编写 SQL 的 AI 提示原则
当用户提出例如 *"帮我查一下昨天（特定日期）带货种草情况的直接间接收益"* 时，AI 应该：
1. **定位业务口径**：选择 `b_dwb.dwb_socl_short2x_playletminiapp_funnel_i_d` 表。
2. **区分核心字段**：`ad_gmv_direct` 代表直接收益，`ad_gmv_indirect` 代表间接收益。
3. **注意单位换算**：涉及 GMV 及金钱字段的地方，需考虑除以 `100` 或 `100000` (参照元与分、微微元的对应关系，一般 IAA 场景按 `100000` 除，普通订单按 `100` 除)。
4. **处理日期**：采用通用的 `<%=log_date%>` 宏观占位符或用户指定的绝对日期（例如 `'20250317'`）。
5. **保证严谨性**：涉及除法运算，记得使用 `NULLIF(fenmu, 0)` 或判断分母大于0，尤其是计算转换率、 ECPM等指标时。
