

好的！以下是完整的知识库文档内容，您可以直接全部复制：

---

# 充电业务数据口径与SQL知识库

> **文档版本**：v1.0  
> **生成时间**：2026-04-14  
> **数据来源**：历史SQL查询记录（共2,824条，去重后2,433条）  
> **覆盖业务**：充电UGC、充电漫剧、课堂、AI动画短剧

---

## 📋 目录

1. [数据概览](#数据概览)
2. [核心数据表说明](#核心数据表说明)
3. [核心指标口径定义](#核心指标口径定义)
4. [关键业务规则](#关键业务规则)
5. [典型分析场景](#典型分析场景)
6. [SQL代码片段库](#sql代码片段库)
7. [数据质量注意事项](#数据质量注意事项)
8. [常见问题FAQ](#常见问题faq)

---

## 数据概览

| 统计项 | 数值 |
|--------|------|
| 原始SQL总数 | 2,824 条 |
| 去重后SQL数 | 2,433 条 |
| 重复率 | 13.85% |
| 涉及核心表 | 15+ 张 |
| 识别业务场景 | 6 个 |

**主要业务领域**：充电业务、动画短剧、流量分发、订单归因、UP主分析

---

## 核心数据表说明

### 1. bi_ogv.dim_ai_donghua_up_list
**【AI动画UP主维度表】**

| 属性 | 说明 |
|------|------|
| 表类型 | 全量快照表 |
| 分区字段 | log_date |
| 数据更新 | 日更新 |

**核心字段**：
- `up_id`：UP主ID
- `up_type`：UP主类型（动画、短剧等）
- `if_institution`：是否为机构（是/否）
- `institution_name`：机构名称
- `if_original`：是否原创（是/否）
- `if_guanfang`：是否官方（是/否）
- `if_donghuaduanju`：是否动画短剧（是/否）

**使用示例**：
```sql
SELECT up_id, up_type, institution_name, if_donghuaduanju
FROM bi_ogv.dim_ai_donghua_up_list
WHERE log_date = (SELECT MAX(log_date) FROM bi_ogv.dim_ai_donghua_up_list)
  AND if_donghuaduanju = '是'
```

---

### 2. bili_ogv.dwb_trd_main_chrg_order_p24h_ascrb_i_d
**【充电订单24小时归因明细表】**

**核心字段**：
- `mid`：用户ID
- `avid`：视频ID
- `up_mid`：UP主ID
- `order_amt`：订单金额（单位：厘，需要/1000转换为元）
- `deduction_type`：扣费类型（0=免费, 1=续费, 2=主动购买）
- `pay_time`：支付时间

**使用示例**：
```sql
-- 统计某UP主的主动GMV
SELECT 
  log_date,
  SUM(order_amt) / 1000 AS active_gmv_yuan
FROM bili_ogv.dwb_trd_main_chrg_order_p24h_ascrb_i_d
WHERE log_date BETWEEN '20260301' AND '20260331'
  AND up_mid = '39627524'
  AND deduction_type = 2
GROUP BY log_date
```

---

### 3. bili_bi.chongdian_av_active_gmv_analysis_d_increment
**【充电视频GMV分析增量表】**

**核心字段**：
- `log_date`：数据日期
- `avid`：视频ID
- `up_id`：UP主ID
- `label`：流量渠道（天马-AI、相关推荐、story等）
- `label_type`：渠道类型（移动端-公域、移动端-私域、非移动端）
- `av_type`：归因类型（未归因、直接订单、间接订单等）
- `vv`：播放量
- `vt`：播放时长（秒）
- `baoyue_active_gmv`：包月主动GMV（元）
- `real_show_pv`：真实曝光PV
- `click_pv`：点击PV
- `first_visable_date`：首次可见日期

**使用示例**：
```sql
-- 充电业务周报核心指标
SELECT 
  ROUND(SUM(CASE WHEN label = 'ott' THEN 0 ELSE vv END) / 7.0 / 10000, 2) AS vv_daily_wan,
  ROUND(SUM(baoyue_active_gmv) / 7.0 / 10000, 2) AS gmv_daily_wan,
  ROUND(SUM(click_pv) * 100.0 / NULLIF(SUM(real_show_pv), 0), 2) AS ctr_pct
FROM bili_bi.chongdian_av_active_gmv_analysis_d_increment
WHERE log_date BETWEEN '20260406' AND '20260412'
```

---

### 4. bili_bi.trad_socl_effi_summary_i_d
**【交易社交效率汇总表】**

**核心字段**：
- `scene_flow`：场景流量（渠道）
- `content_type`：内容类型（充电ugc、充电漫剧、课堂）
- `show_cnt`：业务曝光次数
- `vv`：业务播放量
- `gmv`：成交金额
- `show_cnt_dapan`：大盘曝光次数

**使用示例**：
```sql
-- 策略推荐效率分析
SELECT 
  scene_flow AS channel,
  ROUND(SUM(show_cnt) * 100.0 / NULLIF(SUM(show_cnt_dapan), 0), 2) AS traffic_pct,
  ROUND(SUM(gmv) / 7, 2) AS gmv_daily,
  ROUND(SUM(gmv) * 1000.0 / NULLIF(SUM(show_cnt), 0), 2) AS ecpm
FROM bili_bi.trad_socl_effi_summary_i_d
WHERE log_date BETWEEN '20260408' AND '20260414'
  AND content_type IN ('充电ugc', '充电漫剧', '课堂')
GROUP BY scene_flow
```

---

### 5. b_dwb.dwb_ctnt_arch_play_index_i_d
**【视频播放明细表】**

**核心字段**：
- `mid`：用户ID
- `avid`：视频ID
- `up_id`：UP主ID
- `vv`：播放次数
- `vt`：播放时长
- `stime`：播放开始时间

**使用示例**：
```sql
-- 统计特定视频的播放明细
SELECT 
  log_date,
  COUNT(DISTINCT mid) AS play_users,
  SUM(vv) AS total_vv
FROM b_dwb.dwb_ctnt_arch_play_index_i_d
WHERE log_date BETWEEN '20260301' AND '20260331'
  AND avid = 116327863879389
GROUP BY log_date
```

---

### 6. b_dim.dim_ctnt_arch_business_tag_info_d
**【视频业务标签信息维度表】**

**核心字段**：
- `avid`：视频ID
- `up_id`：UP主ID
- `title`：视频标题
- `tag`：标签（逗号分隔）
- `topic_id`：话题ID
- `first_pub_time`：首次发布时间

**短剧种草活动识别**：
```sql
-- 识别种草活动视频
WHERE (array_contains(split(tag, ','), '短剧种草计划') OR topic_id = '1195749')
```

---

### 7. b_dim.dim_flow_short_x_show_click_hr
**【短视频流量曝光点击小时表】**

**核心字段**：
- `avid`：种草视频ID
- `item_id`：目标视频ID
- `jump_type`：跳转类型（story锚点、蓝链等）
- `event_type`：事件类型（show=曝光、click=点击）
- `event_time`：事件时间（毫秒时间戳）

**使用示例**：
```sql
-- Story锚点的曝光点击统计
SELECT 
  event_type,
  COUNT(*) AS event_cnt
FROM b_dim.dim_flow_short_x_show_click_hr
WHERE log_date BETWEEN '20251016' AND '20251022'
  AND jump_type = 'story锚点'
  AND business_type = '充电'
  AND sub_business_type IN ('充电', '漫剧')
GROUP BY event_type
```

---

### 8. b_dim.dim_ctnt_arch_basic_short_x_jump_content_view_a_hr
**【短视频跳转内容浏览小时表】**

**核心字段**：
- `avid`：种草视频ID（from_av）
- `up_mid`：种草视频UP主ID
- `item_id`：目标视频ID（to_av）
- `item_up_mid`：目标视频UP主ID
- `jump_type`：跳转类型
- `log_hour`：小时（通常取23获取全天数据）

**使用示例**：
```sql
-- 获取种草视频到充电视频的跳转关系
SELECT 
  log_date,
  avid AS from_av,
  item_id AS to_av,
  CASE WHEN up_mid = item_up_mid THEN 'A带A' ELSE 'A带B' END AS jump_type
FROM b_dim.dim_ctnt_arch_basic_short_x_jump_content_view_a_hr
WHERE log_date >= '20250711'
  AND log_hour = 23
  AND item_id_type = 'avid'
  AND business_type = '充电'
```

---

### 9. b_dwb.dwb_ctnt_arch_play_avid_vv_vt_i_d
**【视频播放VV/VT明细表】**

**核心字段**：
- `pid_vv_map`：按端的播放量MAP（如 {'11': 1000, '13': 500}）
- `fan_vv`：粉丝播放量
- `nofan_vv`：非粉丝播放量

**PID说明**：
- `11`：安卓端
- `13`：iOS端

**移动端播放统计**：
```sql
-- 统计移动端播放量（安卓+iOS）
SELECT 
  avid,
  SUM(COALESCE(pid_vv_map['11'], 0) + COALESCE(pid_vv_map['13'], 0)) AS mobile_vv
FROM b_dwb.dwb_ctnt_arch_play_avid_vv_vt_i_d
WHERE log_date BETWEEN '20251016' AND '20251022'
GROUP BY avid
```

---

### 10. bili_main.elec_up_profile_list_a_d
**【充电UP主画像表】**

**核心字段**：
- `up_id`：UP主ID
- `uname`：UP主昵称
- `new_tid_gen`：品类分类（游戏、知识、生活等）
- `fans`：粉丝数

**粉丝分段规则**：
```sql
CASE 
  WHEN fans >= 1000000 THEN '1、100w+'
  WHEN fans >= 100000 THEN '2、10w～100w'
  WHEN fans >= 10000 THEN '3、1w～10w'
  WHEN fans >= 1000 THEN '4、1k～1w'
  ELSE '5、1k-'
END AS fan_level
```

---

### 11. b_dim.dim_socl_short2x_donghuaduanju_zhongcao_up_list
**【动画短剧种草UP主机构名单表】**

**核心字段**：
- `uid`：UP主ID
- `jigou_name`：机构名称
- `insert_date`：插入日期
- `is_delete`：是否删除

**使用示例**：
```sql
-- 关联机构信息
SELECT 
  a.up_id,
  CASE WHEN b.jigou_name IS NULL THEN '个人' ELSE b.jigou_name END AS institution
FROM some_table a
LEFT JOIN b_dim.dim_socl_short2x_donghuaduanju_zhongcao_up_list b 
  ON a.up_id = b.uid
```

---

### 12. b_dwb.dwb_flow_tm_trackid_show_click_vvvt_i_d
**【天马流量trackid级曝光点击播放表】**

**核心字段**：
- `is_vshow`：是否有效曝光
- `is_click`：是否点击
- `vv`：播放量
- `valid_10s_vv`：有效播放≥10秒次数
- `valid_60s_vv`：有效播放≥60秒次数

---

### 13. b_dwb.dwb_flow_story_trackid_show_click_vvvt_i_d
**【Story流量trackid级曝光点击播放表】**

**核心字段**：
- `is_feed`：是否feed流（1=是）
- `is_vshow`：是否有效曝光
- `vt`：播放时长

---

### 14. bili_bi.chongdian_flew_top_up_avid_detail
**【充电流量TOP UP主/稿件明细表】**

**核心字段**：
- `c_date`：订单日期（可用于筛选时间范围）
- `up_id`：UP主ID
- `avid`：视频ID
- `baoyue_active_gmv`：包月主动GMV

**使用示例**：
```sql
-- TOP UP主排行
SELECT 
  up_id, uname, new_tid_gen,
  SUM(CASE WHEN label='ott' THEN 0 ELSE vv END) AS vv,
  SUM(baoyue_active_gmv) AS gmv
FROM bili_bi.chongdian_flew_top_up_avid_detail
WHERE log_date = (SELECT MAX(log_date) FROM bili_bi.chongdian_flew_top_up_avid_detail)
  AND c_date BETWEEN '20260406' AND '20260412'
GROUP BY up_id, uname, new_tid_gen
ORDER BY gmv DESC
LIMIT 50
```

---

### 15. bili_main.dwd_trd_chg_order_w_metrics_i_a_hr
**【充电订单指标表（小时级）】**

**核心字段**：
- `mid`：用户ID
- `up_mid`：UP主ID
- `cost`：订单金额（单位：厘）
- `deduction_type`：扣费类型

**使用场景**：续费/拉新/召回分析

---

## 核心指标口径定义

### 1. GMV（成交金额）

#### 1.1 主动GMV (active_gmv)
- **定义**：用户主动购买产生的成交金额
- **计算逻辑**：`SUM(order_amt) / 1000`
- **筛选条件**：`deduction_type = 2`
- **单位**：元（原始数据单位：厘，需要除以1000）

#### 1.2 包月主动GMV (baoyue_active_gmv)
- **定义**：包月订单中的主动购买GMV（排除续费）
- **筛选条件**：
  ```sql
  deduction_type = 2 
  AND biz_class != '自定义充电' 
  AND context_type != 5
  ```
- **单位**：元
- **说明**：context_type=5代表续费，需排除

#### 1.3 续费GMV
- **定义**：自动续费产生的GMV
- **筛选条件**：`deduction_type = 1` 或 `context_type = 5`
- **单位**：元

#### 1.4 订单类型分类（deduction_type）
| 值 | 含义 | 业务说明 |
|----|------|----------|
| 0 | 免费 | 免费订单 |
| 1 | 续费 | 自动续订 |
| 2 | 主动购买 | 用户主动下单 |

#### 1.5 续费/拉新/召回分类逻辑
```sql
CASE 
  WHEN deduction_type = 1 THEN '续费'
  WHEN deduction_type = 2 AND first_pay_time = log_date THEN '主动-拉新'
  WHEN deduction_type = 2 AND first_pay_time < log_date THEN '主动-召回'
  ELSE '其他'
END AS order_category
```

**实现步骤**：
1. 先创建首次付费时间表 `tmp_ogv.shipindao_xufeimid`
2. 关联订单表，根据 `first_pay_time` 判断是否为纯新用户

---

### 2. VV（播放量）

- **定义**：Video View，视频播放次数
- **数据来源**：
  - `b_dwb.dwb_ctnt_arch_play_index_i_d.vv`
  - `b_dwb.dwb_ctnt_arch_play_avid_vv_vt_i_d`

#### 移动端VV统计
```sql
-- 方法1：从 pid_vv_map 提取移动端播放
COALESCE(pid_vv_map['11'], 0) + COALESCE(pid_vv_map['13'], 0) AS mobile_vv

-- 方法2：排除OTT端
CASE WHEN label = 'ott' THEN 0 ELSE vv END AS mobile_vv
```

#### 粉丝/非粉丝播放区分
- `fan_vv`：粉丝播放量
- `nofan_vv`：非粉丝播放量

---

### 3. VT（播放时长）

- **定义**：Video Time，视频播放总时长
- **单位**：秒（原始），转换为分钟需要 `/ 60`

#### 有效播放统计
- `valid_10s_vv`：播放≥10秒的次数
- `valid_60s_vv`：播放≥60秒的次数

#### 单位转换示例
```sql
-- 日均播放时长（万分钟）
ROUND(SUM(vt) / 7.0 / 60.0 / 10000, 2) AS vt_daily_wan_min
```

---

### 4. CTR（点击率）

- **定义**：点击率 = 点击数 / 曝光数
- **计算公式**：`SUM(click_pv) * 100.0 / NULLIF(SUM(real_show_pv), 0)`
- **单位**：百分比（%）

**完整计算示例**：
```sql
SELECT 
  label AS channel,
  ROUND(SUM(click_pv) * 100.0 / NULLIF(SUM(real_show_pv), 0), 2) AS ctr_pct
FROM bili_bi.chongdian_av_active_gmv_analysis_d_increment
WHERE log_date BETWEEN '20260406' AND '20260412'
GROUP BY label
```

---

### 5. ECPM（千次曝光收入）

- **定义**：每千次曝光产生的收入
- **计算公式**：`SUM(baoyue_active_gmv) * 1000.0 / NULLIF(SUM(real_show_pv), 0)`
- **单位**：元

**完整计算示例**：
```sql
SELECT 
  label AS channel,
  ROUND(SUM(baoyue_active_gmv) * 1000.0 / NULLIF(SUM(real_show_pv), 0), 2) AS ecpm
FROM bili_bi.chongdian_av_active_gmv_analysis_d_increment
WHERE log_date BETWEEN '20260406' AND '20260412'
GROUP BY label
```

---

### 6. 流量占比

- **定义**：业务流量占大盘流量的比例
- **计算公式**：`SUM(show_cnt) * 100.0 / NULLIF(SUM(show_cnt_dapan), 0)`
- **单位**：百分比（%）
- **数据来源**：`bili_bi.trad_socl_effi_summary_i_d`

---

### 7. 单曝光时长

- **定义**：平均每次曝光的播放时长
- **计算公式**：`SUM(vt) / NULLIF(SUM(show_cnt), 0)`
- **单位**：秒

---

## 关键业务规则

### 1. 流量渠道分类

#### 渠道明细（label / srcchnl_name）

| 渠道类型 | 具体渠道 |
|----------|----------|
| **天马** | 天马-AI、天马-运营、天马-其他、天马-商业 |
| **Story** | story-上下滑、story-其他 |
| **相关推荐** | 相关推荐-AI、相关推荐-运营 |
| **搜索** | 搜索 |
| **空间页** | 空间页 |
| **动态** | 动态 |
| **播放页** | 播放页 |
| **其他** | pc、ipad、ott、h5、热门、push等 |

#### 渠道类型分组（label_type）

```sql
CASE
  WHEN srcchnl_name IN ('pc', 'ipad', 'ott', 'h5') THEN '非移动端'
  WHEN srcchnl_name IN (
    '天马-AI', '天马-其他', '天马-运营',
    'story-上下滑', 'story-其他',
    '相关推荐-AI', '热门', '搜索', '相关推荐-运营'
  ) OR srcchnl_name RLIKE '天马-商业' THEN '移动端-公域'
  WHEN srcchnl_name IN ('空间页', '我的页金刚位', '动态', '播放页', 'push') THEN '移动端-私域'
  ELSE '其他'
END AS label_type
```

#### 渠道简化分组
```sql
CASE
  WHEN srcchnl_name RLIKE '天马' THEN '天马'
  WHEN srcchnl_name RLIKE 'story' THEN 'story'
  WHEN srcchnl_name RLIKE '相关推荐' THEN '相关推荐'
  WHEN srcchnl_name RLIKE '搜索' THEN '搜索'
  ELSE srcchnl_name
END AS label
```

---

### 2. 归因类型（av_type）

| 归因类型 | 说明 |
|----------|------|
| **未归因** | 无法归因到具体视频的订单 |
| **可归因** | 可归因到具体视频的订单 |
| **直接订单** | 用户直接在视频页下单 |
| **间接订单-先看后买** | 用户先观看视频，后续24小时内下单 |

**可归因GMV统计**：
```sql
SUM(CASE WHEN av_type != '未归因' THEN baoyue_active_gmv ELSE 0 END) AS gmv_guiyin
```

---

### 3. 短剧种草活动识别

**识别规则**：
- **标签识别**：`array_contains(split(tag, ','), '短剧种草计划')`
- **话题识别**：`topic_id = '1195749'`
- **用途**：识别参与种草活动的免费视频

**完整SQL示例**：
```sql
SELECT avid, title, uname
FROM b_dim.dim_ctnt_arch_business_tag_info_d
WHERE log_date = '20260414'
  AND (array_contains(split(tag, ','), '短剧种草计划') OR topic_id = '1195749')
  AND avid NOT IN (
    SELECT DISTINCT avid 
    FROM b_dim.dim_ctnt_arch_charge_info_a_d 
    WHERE log_date = '20260414'
  )
```

---

### 4. UP主分类维度

#### 4.1 品类分类（new_tid_gen）
- **说明**：UP主品类，如游戏、知识、生活、娱乐、动画等
- **来源**：`bili_main.elec_up_profile_list_a_d.new_tid_gen`

#### 4.2 粉丝分段（fan_level）
```sql
CASE 
  WHEN fans >= 1000000 THEN '1、100w+'
  WHEN fans >= 100000 THEN '2、10w～100w'
  WHEN fans >= 10000 THEN '3、1w～10w'
  WHEN fans >= 1000 THEN '4、1k～1w'
  ELSE '5、1k-'
END AS fan_level
```

#### 4.3 机构归属
- `if_institution`：是否为机构UP（是/否）
- `institution_name`：机构名称
- `jigou_name`：机构名称（种草名单表字段）

---

### 5. 充电业务类型（content_type）

| 业务类型 | content_type | 说明 |
|----------|--------------|------|
| 充电UGC | 充电ugc | UP主付费视频 |
| 充电漫剧 | 充电漫剧 | 短剧形式的付费内容 |
| 课堂 | 课堂 | 知识付费课程 |

---

### 6. 端类型（PID）

| PID | 端类型 |
|-----|--------|
| 11 | 安卓端 |
| 13 | iOS端 |

**使用示例**：
```sql
-- 提取移动端播放量
COALESCE(pid_vv_map['11'], 0) + COALESCE(pid_vv_map['13'], 0) AS mobile_vv
```

---

### 7. 日期处理函数

| 函数 | 说明 | 示例 |
|------|------|------|
| `b_date_add(date, n)` | 日期加减n天 | `b_date_add('20260414', -7)` → '20260407' |
| `b_date_parse(log_date)` | yyyyMMdd转可读日期 | `b_date_parse('20260414')` → '2026-04-14' |
| `b_current_datedelta('-1')` | 获取昨天日期 | `b_current_datedelta('-1')` → '20260413' |
| `b_date_add(pubtime, 0)` | 提取日期部分 | `b_date_add('2026-04-14 10:30:00', 0)` → '20260414' |

---

## 典型分析场景

### 场景1：UP主续费/主动收入分类分析

**业务目标**：分析特定UP主的订单类型分布（续费/主动-拉新/主动-召回）

#### Step 1：创建首次付费时间基础表

```sql
CREATE TABLE IF NOT EXISTS tmp_ogv.shipindao_xufeimid AS 
SELECT 
  mid,
  MIN(log_date) AS first_pay_time
FROM bili_main.dwd_trd_chg_order_w_metrics_i_a_hr
WHERE log_date >= 20240101
  AND up_mid = '326246517'  -- 替换为目标UP主ID
  AND deduction_type IN (0, 2)
GROUP BY mid
```

#### Step 2：订单分类统计

```sql
SELECT 
  log_date,
  CASE 
    WHEN deduction_type = 1 THEN '续费'
    WHEN deduction_type = 2 AND first_pay_time = log_date THEN '主动-拉新'
    WHEN deduction_type = 2 AND first_pay_time < log_date THEN '主动-召回'
  END AS order_category,
  SUM(cost) / 1000 AS gmv
FROM bili_main.dwd_trd_chg_order_w_metrics_i_a_hr a
LEFT JOIN tmp_ogv.shipindao_xufeimid b ON a.mid = b.mid
WHERE log_date >= 20230101
  AND up_mid = '326246517'
GROUP BY log_date, 
  CASE 
    WHEN deduction_type = 1 THEN '续费'
    WHEN deduction_type = 2 AND first_pay_time = log_date THEN '主动-拉新'
    WHEN deduction_type = 2 AND first_pay_time < log_date THEN '主动-召回'
  END
ORDER BY log_date
```

---

### 场景2：短剧种草活动效果分析

**业务目标**：分析种草视频（from_av）跳转到付费视频（to_av）的转化效果

#### 完整SQL逻辑

```sql
-- Step 1: 圈定种草稿件
WITH activity_av AS (
  SELECT
    avid,
    topic_id,
    uname,
    split(tag, ',') AS tag,
    b_date_add(first_pub_time, 0) AS from_av_pubtime,
    title AS from_av_title
  FROM b_dim.dim_ctnt_arch_business_tag_info_d
  WHERE log_date = '20260414'
    AND avid > 0
    -- 排除充电视频
    AND avid NOT IN (
      SELECT DISTINCT avid 
      FROM b_dim.dim_ctnt_arch_charge_info_a_d 
      WHERE log_date = '20260414'
    )
    -- 识别种草活动
    AND (array_contains(split(tag, ','), '短剧种草计划') OR topic_id = '1195749')
    AND b_date_add(first_pub_time, 0) >= '20250711'
),

-- Step 2: 识别跳转关系
av_mapping AS (
  SELECT DISTINCT
    a.log_date,
    a.avid AS from_avid,
    a.up_mid AS from_av_up,
    a.item_id AS to_avid,
    a.item_up_mid AS to_av_up,
    CASE WHEN a.up_mid = a.item_up_mid THEN 'A带A' ELSE 'A带B' END AS jump_type,
    CASE WHEN b.jigou_name IS NULL THEN '个人' ELSE b.jigou_name END AS from_av_institution
  FROM b_dim.dim_ctnt_arch_basic_short_x_jump_content_view_a_hr a
  LEFT JOIN b_dim.dim_socl_short2x_donghuaduanju_zhongcao_up_list b ON b.uid = a.up_mid
  WHERE a.log_date >= '20250711'
    AND a.log_hour = 23
    AND a.item_id_type = 'avid'
    AND a.business_type = '充电'
    AND a.avid IN (SELECT avid FROM activity_av)
),

-- Step 3: 蓝链曝光点击
blue_click AS (
  SELECT
    log_date,
    avid AS from_avid,
    item_id AS to_avid,
    SUM(CASE WHEN event_type = 'click' THEN 1 ELSE 0 END) AS click_pv,
    SUM(CASE WHEN event_type = 'show' THEN 1 ELSE 0 END) AS show_pv
  FROM b_dim.dim_flow_short_x_show_click_hr
  WHERE log_date >= '20250711'
    AND item_id_type = 'avid'
  GROUP BY log_date, avid, item_id
),

-- Step 4: from_av播放量
from_av_vv AS (
  SELECT
    a.log_date,
    a.avid AS from_avid,
    b.to_avid,
    SUM(vv) AS vv
  FROM b_dwb.dwb_ctnt_arch_play_index_i_d a
  INNER JOIN (
    SELECT log_date, from_avid, to_avid 
    FROM av_mapping 
    GROUP BY log_date, from_avid, to_avid
  ) b ON a.avid = b.from_avid AND a.log_date = b.log_date
  WHERE a.log_date >= '20250711'
    AND vv > 0
    AND mid > 0
  GROUP BY a.log_date, a.avid, b.to_avid
),

-- Step 5: 订单归因（24小时窗口）
user_pay AS (
  SELECT
    log_date,
    mid,
    avid AS to_avid,
    order_id,
    pay_time AS order_timestamp,
    SUM(order_amt) / 1000 AS active_gmv
  FROM bili_ogv.dwb_trd_main_chrg_order_p24h_ascrb_i_d
  WHERE log_date >= '20250711'
    AND mid > 0
    AND deduction_type = 2
  GROUP BY log_date, mid, avid, order_id, pay_time
)

-- 汇总输出
SELECT
  a.log_date,
  a.from_avid,
  a.to_avid,
  a.jump_type,
  COALESCE(v.vv, 0) AS from_vv,
  COALESCE(b.show_pv, 0) AS show_pv,
  COALESCE(b.click_pv, 0) AS click_pv,
  SUM(COALESCE(p.active_gmv, 0)) AS active_gmv
FROM av_mapping a
LEFT JOIN from_av_vv v ON a.log_date = v.log_date AND a.from_avid = v.from_avid AND a.to_avid = v.to_avid
LEFT JOIN blue_click b ON a.log_date = b.log_date AND a.from_avid = b.from_avid AND a.to_avid = b.to_avid
LEFT JOIN user_pay p ON a.to_avid = p.to_avid AND a.log_date = p.log_date
GROUP BY a.log_date, a.from_avid, a.to_avid, a.jump_type, v.vv, b.show_pv, b.click_pv
```

---

### 场景3：Story锚点流量效果统计

**业务目标**：统计Story锚点跳转的流量规模和转化效果

```sql
-- Story锚点的曝光、点击、from_av数、to_av数统计
WITH story_mapping AS (
  SELECT DISTINCT 
    avid AS from_avid,
    item_id AS to_avid
  FROM b_dim.dim_ctnt_arch_basic_short_x_jump_content_view_a_hr
  WHERE log_date BETWEEN '20251016' AND '20251022'
    AND log_hour = 23
    AND jump_type = 'story锚点'
    AND business_type = '充电'
    AND sub_business_type IN ('充电', '漫剧')
)

SELECT 
  -- 曝光点击统计
  SUM(CASE WHEN event_type = 'show' THEN 1 END) AS show_pv,
  SUM(CASE WHEN event_type = 'click' THEN 1 END) AS click_pv,
  -- from_av和to_av去重计数
  COUNT(DISTINCT avid) AS from_av_num,
  COUNT(DISTINCT item_id) AS to_av_num
FROM b_dim.dim_flow_short_x_show_click_hr
WHERE log_date BETWEEN '20251016' AND '20251022'
  AND jump_type = 'story锚点'
  AND business_type = '充电'
  AND sub_business_type IN ('充电', '漫剧')
```

**from_av播放量统计（移动端）**：
```sql
SELECT 
  SUM(COALESCE(pid_vv_map['11'], 0) + COALESCE(pid_vv_map['13'], 0)) AS total_mobile_vv
FROM b_dwb.dwb_ctnt_arch_play_avid_vv_vt_i_d
WHERE log_date BETWEEN '20251016' AND '20251022'
  AND avid IN (
    SELECT DISTINCT avid 
    FROM b_dim.dim_flow_short_x_show_click_hr
    WHERE log_date BETWEEN '20251016' AND '20251022'
      AND jump_type = 'story锚点'
      AND business_type = '充电'
  )
```

---

### 场景4：充电业务周报核心指标

**业务目标**：生成充电业务的周度核心指标（VV、VT、曝光、GMV、CTR、ECPM等）

#### 标准周报SQL模板

```sql
SELECT 
  '本期(0406-0412)' AS period,
  -- 播放指标（日均，万为单位）
  ROUND(SUM(CASE WHEN label = 'ott' THEN 0 ELSE vv END) / 7.0 / 10000, 2) AS vv_daily_wan,
  ROUND(SUM(CASE WHEN label = 'ott' THEN 0 ELSE vt END) / 7.0 / 60.0 / 10000, 2) AS vt_daily_wan_min,
  -- 曝光点击指标（日均，万为单位）
  ROUND(SUM(real_show_pv) / 7.0 / 10000, 2) AS show_pv_daily_wan,
  ROUND(SUM(click_pv) / 7.0 / 10000, 2) AS click_pv_daily_wan,
  -- GMV指标（日均，万元为单位）
  ROUND(SUM(baoyue_active_gmv) / 7.0 / 10000, 2) AS baoyue_gmv_daily_wan,
  ROUND(SUM(CASE WHEN av_type != '未归因' THEN baoyue_active_gmv ELSE 0 END) / 7.0 / 10000, 2) AS baoyue_gmv_guiyin_daily_wan,
  -- 转化率指标
  ROUND(SUM(click_pv) * 100.0 / NULLIF(SUM(real_show_pv), 0), 2) AS ctr_pct,
  -- 效率指标
  ROUND(SUM(baoyue_active_gmv) * 1000.0 / NULLIF(SUM(real_show_pv), 0), 2) AS ecpm,
  -- 内容指标
  COUNT(DISTINCT CASE WHEN first_visable_date BETWEEN '20260406' AND '20260412' THEN avid END) AS new_avnum
FROM bili_bi.chongdian_av_active_gmv_analysis_d_increment
WHERE log_date BETWEEN '20260406' AND '20260412'

UNION ALL

SELECT 
  '上期(0330-0405)' AS period,
  ROUND(SUM(CASE WHEN label = 'ott' THEN 0 ELSE vv END) / 7.0 / 10000, 2),
  ROUND(SUM(CASE WHEN label = 'ott' THEN 0 ELSE vt END) / 7.0 / 60.0 / 10000, 2),
  ROUND(SUM(real_show_pv) / 7.0 / 10000, 2),
  ROUND(SUM(click_pv) / 7.0 / 10000, 2),
  ROUND(SUM(baoyue_active_gmv) / 7.0 / 10000, 2),
  ROUND(SUM(CASE WHEN av_type != '未归因' THEN baoyue_active_gmv ELSE 0 END) / 7.0 / 10000, 2),
  ROUND(SUM(click_pv) * 100.0 / NULLIF(SUM(real_show_pv), 0), 2),
  ROUND(SUM(baoyue_active_gmv) * 1000.0 / NULLIF(SUM(real_show_pv), 0), 2),
  COUNT(DISTINCT CASE WHEN first_visable_date BETWEEN '20260330' AND '20260405' THEN avid END)
FROM bili_bi.chongdian_av_active_gmv_analysis_d_increment
WHERE log_date BETWEEN '20260330' AND '20260405'
```

---

### 场景5：策略推荐效率分析

**业务目标**：分析不同推荐策略的流量和转化效率

```sql
SELECT 
  scene_flow AS channel,
  content_type AS business_type,
  -- 流量占比（业务曝光/大盘曝光）
  ROUND(SUM(show_cnt) * 100.0 / NULLIF(SUM(show_cnt_dapan), 0), 2) AS traffic_pct,
  -- 收入指标
  ROUND(SUM(gmv), 2) AS gmv_total,
  ROUND(SUM(gmv) / 7, 2) AS gmv_daily,
  -- 效率指标
  ROUND(SUM(vt) * 1.0 / NULLIF(SUM(show_cnt), 0), 2) AS vt_per_show,
  ROUND(SUM(gmv) * 1000.0 / NULLIF(SUM(show_cnt), 0), 2) AS ecpm
FROM bili_bi.trad_socl_effi_summary_i_d
WHERE log_date BETWEEN '20260408' AND '20260414'
  AND content_type IN ('充电ugc', '充电漫剧', '课堂')
GROUP BY scene_flow, content_type
ORDER BY gmv_total DESC
```

---

### 场景6：TOP UP主/稿件排行

**业务目标**：统计GMV或播放量TOP的UP主和稿件

#### TOP UP主排行
```sql
SELECT 
  up_id,
  uname,
  new_tid_gen,
  SUM(CASE WHEN label = 'ott' THEN 0 ELSE vv END) AS vv,
  SUM(baoyue_active_gmv) AS gmv
FROM bili_bi.chongdian_flew_top_up_avid_detail
WHERE log_date = (SELECT MAX(log_date) FROM bili_bi.chongdian_flew_top_up_avid_detail)
  AND c_date BETWEEN '20260406' AND '20260412'
GROUP BY up_id, uname, new_tid_gen
ORDER BY gmv DESC
LIMIT 50
```

#### TOP稿件排行
```sql
SELECT 
  up_id,
  uname,
  avid,
  bvid,
  title,
  new_tid_gen,
  ROUND(SUM(CASE WHEN label = 'ott' THEN 0 ELSE vv END) / 10000, 2) AS vv_wan,
  ROUND(SUM(baoyue_active_gmv) / 10000, 2) AS gmv_wan,
  ROUND(SUM(click_pv) * 100.0 / NULLIF(SUM(real_show_pv), 0), 2) AS ctr_pct
FROM bili_bi.chongdian_flew_top_up_avid_detail
WHERE log_date = (SELECT MAX(log_date) FROM bili_bi.chongdian_flew_top_up_avid_detail)
  AND c_date BETWEEN '20260406' AND '20260412'
GROUP BY up_id, uname, avid, bvid, title, new_tid_gen
ORDER BY gmv_wan DESC
LIMIT 10
```

---

## SQL代码片段库

### 1. 常用时间筛选

```sql
-- 最近7天
WHERE log_date BETWEEN b_date_add(b_current_datedelta('-1'), -6) 
  AND b_current_datedelta('-1')

-- 最近30天
WHERE log_date BETWEEN b_date_add(b_current_datedelta('-1'), -29) 
  AND b_current_datedelta('-1')

-- 本月至今
WHERE log_date BETWEEN CONCAT(SUBSTR(b_current_datedelta('-1'), 1, 6), '01')
  AND b_current_datedelta('-1')

-- 昨天
WHERE log_date = b_current_datedelta('-1')

-- 指定时间范围
WHERE log_date BETWEEN '20260301' AND '20260331'
```

---

### 2. 获取最新分区数据

```sql
-- 方法1：子查询
SELECT *
FROM bi_ogv.dim_ai_donghua_up_list
WHERE log_date = (SELECT MAX(log_date) FROM bi_ogv.dim_ai_donghua_up_list)

-- 方法2：窗口函数
SELECT *
FROM (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY up_id ORDER BY log_date DESC) AS rn
  FROM bi_ogv.dim_ai_donghua_up_list
) t
WHERE rn = 1
```

---

### 3. 移动端指标统计

```sql
-- 方法1：排除OTT端的VV
SUM(CASE WHEN label = 'ott' THEN 0 ELSE vv END) AS mobile_vv

-- 方法2：从pid_vv_map提取移动端播放
COALESCE(pid_vv_map['11'], 0) + COALESCE(pid_vv_map['13'], 0) AS mobile_vv

-- 方法3：使用PID过滤
WHERE pid IN (11, 13)
```

---

### 4. 日均/环比计算

```sql
-- 日均计算（7天周期）
ROUND(SUM(gmv) / 7.0, 2) AS gmv_daily

-- 日均计算（按实际天数）
ROUND(SUM(gmv) / COUNT(DISTINCT log_date), 2) AS gmv_daily

-- 环比计算
ROUND((curr_gmv - prev_gmv) * 100.0 / NULLIF(prev_gmv, 0), 2) AS mom_pct

-- 单位换算
ROUND(SUM(vv) / 10000, 2) AS vv_wan  -- 播放量（万）
ROUND(SUM(vt) / 60 / 10000, 2) AS vt_wan_min  -- 时长（万分钟）
ROUND(SUM(gmv) / 10000, 2) AS gmv_wan  -- GMV（万元）
```

---

### 5. 安全的除法运算

```sql
-- 避免除零错误
ROUND(numerator * 100.0 / NULLIF(denominator, 0), 2) AS ratio

-- 使用COALESCE设置默认值
COALESCE(numerator / NULLIF(denominator, 0), 0) AS ratio

-- 多层保护
CASE 
  WHEN denominator = 0 OR denominator IS NULL THEN 0
  ELSE ROUND(numerator / denominator, 2)
END AS ratio
```

---

### 6. 数组处理

```sql
-- 判断数组包含
array_contains(split(tag, ','), '短剧种草计划')

-- 拆分字符串为数组
split(tag, ',') AS tag_array

-- 数组元素提取
tag_array[0] AS first_tag

-- 多条件OR匹配
WHERE (
  array_contains(split(tag, ','), '短剧种草计划')
  OR topic_id = '1195749'
)
```

---

### 7. 排除特定视频

```sql
-- 排除特定BV号视频
WHERE item_id NOT IN (
  b_bv2av('BV1icEuzEE7b'),
  b_bv2av('BV1TP76z9Ed3'),
  b_bv2av('BV1heJNzPEwC'),
  b_bv2av('BV1vbEWzxEfY'),
  b_bv2av('BV1QZEpz2E61'),
  b_bv2av('BV16HEWzcECZ')
)

-- 排除充电视频
WHERE avid NOT IN (
  SELECT DISTINCT avid 
  FROM b_dim.dim_ctnt_arch_charge_info_a_d 
  WHERE log_date = '20260414'
)
```

---

### 8. 条件聚合

```sql
-- 按渠道分组统计
SUM(IF(srcchnl_name = '相关推荐-AI', vv, 0)) AS rec_vv,
SUM(IF(srcchnl_name = '天马', vv, 0)) AS tm_vv,
SUM(IF(srcchnl_name IN ('story-上下滑', 'story-其他'), vv, 0)) AS story_vv

-- 按条件统计GMV
SUM(CASE WHEN av_type != '未归因' THEN baoyue_active_gmv ELSE 0 END) AS gmv_guiyin,
SUM(CASE WHEN deduction_type = 2 THEN order_amt / 1000 ELSE 0 END) AS active_gmv
```

---

## 数据质量注意事项

### 1. 时间窗口

| 场景 | 规则 | 说明 |
|------|------|------|
| 订单归因窗口 | 24小时 | `order_timestamp - event_time BETWEEN 0 AND 60*60*24` |
| 跨天归因 | 查询前一天数据 | `log_date BETWEEN b_date_add(user_pay.log_date, -1) AND user_pay.log_date` |
| 发布后N天统计 | 动态计算 | `DATEDIFF(log_date, publish_date) BETWEEN 0 AND N-1` |

---

### 2. 数据分区

| 表类型 | 分区策略 | 查询建议 |
|--------|----------|----------|
| 增量表 | 按log_date分区 | 必须带log_date筛选条件 |
| 全量快照表 | log_date表示快照日期 | 通常取`MAX(log_date)` |
| 小时表 | log_date + log_hour | 分析时通常取`log_hour=23`获取全天数据 |

---

### 3. 去重逻辑

#### UP主维度表去重
```sql
-- 取最新分区
WHERE log_date = (SELECT MAX(log_date) FROM bi_ogv.dim_ai_donghua_up_list)
```

#### 稿件信息去重
```sql
-- 按avid去重，取最新记录
SELECT avid, title, up_id, uname
FROM b_dim.dim_ctnt_arch_business_tag_info_d
WHERE log_date = b_current_datedelta('-1')
GROUP BY avid, title, up_id, uname
```

#### 用户DAU去重
```sql
-- 同一天同一个用户只保留一条
SELECT log_date, mid, ...
FROM (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY log_date, mid ORDER BY 1) AS rn
  FROM table_name
) t
WHERE rn = 1
```

---

### 4. 常见排除项

| 场景 | 排除逻辑 | 原因 |
|------|----------|------|
| 排除续费 | `context_type != 5` 或 `deduction_type != 1` | 分析主动购买时需排除 |
| 排除自定义充电 | `biz_class != '自定义充电'` | 非标准充电包月业务 |
| 排除充电视频 | `avid NOT IN (SELECT avid FROM dim_ctnt_arch_charge_info_a_d)` | 筛选免费种草视频时使用 |
| 排除特定视频 | `item_id NOT IN (b_bv2av('BV号'), ...)` | 排除测试或异常视频 |
| 排除OTT端 | `label != 'ott'` | 计算移动端指标时使用 |

---

### 5. 数据时效性

| 表名 | 更新时间 | 数据延迟 | 注意事项 |
|------|----------|----------|----------|
| dwb_trd_main_chrg_order_p24h_ascrb_i_d | T+1早晨 | 约1天 | 订单归因需24小时完成 |
| chongdian_av_active_gmv_analysis_d_increment | T+1早晨 | 约1天 | 汇总层，依赖上游明细表 |
| dim_ctnt_arch_business_tag_info_d | T+1早晨 | 约1天 | 快照表 |

**建议**：
- 查询"昨天"数据时，使用 `log_date = b_current_datedelta('-1')`
- 避免查询"今天"数据，可能不完整

---

### 6. 性能优化建议

#### 6.1 分区裁剪
```sql
-- ✅ 正确：带分区筛选
WHERE log_date BETWEEN '20260301' AND '20260331'

-- ❌ 错误：不带分区筛选（全表扫描）
WHERE b_date_parse(log_date) >= '2026-03-01'
```

#### 6.2 先筛选后JOIN
```sql
-- ✅ 正确：先筛选再JOIN
WITH filtered_orders AS (
  SELECT * FROM orders WHERE log_date = '20260414' AND up_id IN (...)
)
SELECT a.* FROM filtered_orders a JOIN other_table b ON ...

-- ❌ 错误：先JOIN后筛选
SELECT a.* FROM orders a JOIN other_table b ON ... WHERE a.log_date = '20260414'
```

#### 6.3 使用LIMIT
```sql
-- 测试SQL时加LIMIT
SELECT * FROM large_table WHERE ... LIMIT 100
```

#### 6.4 避免SELECT *
```sql
-- ✅ 正确：指定需要的字段
SELECT avid, up_id, vv, gmv FROM table_name

-- ❌ 错误：查询所有字段
SELECT * FROM table_name
```

---

## 常见问题FAQ

### Q1：为什么 order_amt 要除以 1000？
**A**：订单金额字段 `order_amt` 的单位是"厘"（1元=1000厘），需要除以1000转换为"元"。

**示例**：
```sql
-- order_amt = 5000（厘）→ 5000 / 1000 = 5（元）
SUM(order_amt) / 1000 AS gmv_yuan
```

---

### Q2：deduction_type 和 context_type 的区别？
**A**：
- `deduction_type`：扣费类型（0=免费, 1=续费, 2=主动）
- `context_type`：订单上下文类型，其中 5=续费订单
- 排除续费时建议同时使用：`deduction_type = 2 AND context_type != 5`

**为什么要同时用两个条件？**
- `deduction_type = 1` 明确标识为续费
- 但部分续费订单可能 `deduction_type = 2` 但 `context_type = 5`
- 双重保险，确保完全排除续费

---

### Q3：如何区分"A带A"和"A带B"？
**A**：
```sql
CASE 
  WHEN from_av_up_id = to_av_up_id THEN 'A带A'  -- 同一UP主的视频互相导流
  ELSE 'A带B'  -- 跨UP主导流
END AS jump_type
```

**业务意义**：
- **A带A**：UP主自家视频互导，属于私域流量运营
- **A带B**：跨UP主导流，通常是种草活动场景

---

### Q4：24小时归因的宽口径和窄口径区别？
**A**：
- **宽口径（基于播放）**：用户播放了from_av后24小时内购买to_av，归因到from_av
- **窄口径（基于蓝链点击）**：用户点击from_av中的蓝链后24小时内购买，归因到from_av
- **差异**：窄口径要求必须有点击行为，更严格，GMV会更低

**归因窗口计算**：
```sql
-- 24小时 = 60秒 * 60分钟 * 24小时
WHERE order_timestamp - event_time BETWEEN 0 AND 60*60*24
```

---

### Q5：如何获取最新的UP主分类信息？
**A**：
```sql
-- 方法1：子查询
WHERE log_date = (SELECT MAX(log_date) FROM bi_ogv.dim_ai_donghua_up_list)

-- 方法2：直接指定最新日期（如果知道）
WHERE log_date = '20260414'
```

**为什么要这样做？**
- `dim_ai_donghua_up_list` 是全量快照表，每天都有所有UP主的记录
- 不取最新分区会导致重复数据

---

### Q6：Story锚点和蓝链的区别？
**A**：
- **Story锚点**：Story模式下的视频推荐跳转（`jump_type = 'story锚点'`）
- **蓝链**：视频中嵌入的可点击链接（`jump_type = '蓝链'`）

**数据表**：
- 都可以从 `dim_flow_short_x_show_click_hr` 查询
- 通过 `jump_type` 字段区分

---

### Q7：如何排除测试数据？
**A**：
```sql
-- 排除特定测试视频
WHERE item_id NOT IN (
  b_bv2av('BV1icEuzEE7b'),  -- 测试视频1
  b_bv2av('BV1TP76z9Ed3')   -- 测试视频2
)

-- 排除测试用户
WHERE mid > 0  -- 通常测试mid为负数或0

-- 排除异常数据
WHERE vv > 0 AND mid > 0 AND avid > 0
```

---

### Q8：如何处理数组字段（如 tag）？
**A**：
```sql
-- 拆分为数组
split(tag, ',') AS tag_array

-- 判断数组包含某个元素
array_contains(split(tag, ','), '短剧种草计划')

-- 数组元素遍历（使用 explode）
SELECT explode(split(tag, ',')) AS single_tag
FROM table_name
```

---

### Q9：如何计算用户首次付费时间？
**A**：
```sql
-- 创建首次付费时间表
CREATE TABLE IF NOT EXISTS tmp_ogv.shipindao_xufeimid AS 
SELECT 
  mid,
  MIN(log_date) AS first_pay_time
FROM bili_main.dwd_trd_chg_order_w_metrics_i_a_hr
WHERE log_date >= 20240101
  AND up_mid = '326246517'
  AND deduction_type IN (0, 2)  -- 首次付费或主动购买
GROUP BY mid
```

---

### Q10：如何区分充电视频和免费视频？
**A**：
```sql
-- 方法1：使用 dim_ctnt_arch_charge_info_a_d
WHERE avid IN (
  SELECT DISTINCT avid 
  FROM b_dim.dim_ctnt_arch_charge_info_a_d 
  WHERE log_date = '20260414'
)

-- 方法2：使用 is_charging_pay 字段
WHERE is_charging_pay = 1  -- 1=充电视频, 0=免费视频
```

---

## 附录：高频使用的表关联关系

### 1. UP主信息关联

```sql
-- UP主基础信息 + 画像信息
SELECT 
  a.up_id,
  a.institution_name,  -- 机构名称
  b.new_tid_gen,       -- 品类
  b.fans               -- 粉丝数
FROM bi_ogv.dim_ai_donghua_up_list a
LEFT JOIN bili_main.elec_up_profile_list_a_d b 
  ON CAST(a.up_id AS STRING) = CAST(b.up_id AS STRING)
  AND b.log_date = '20260401'
WHERE a.log_date = (SELECT MAX(log_date) FROM bi_ogv.dim_ai_donghua_up_list)
```

---

### 2. 视频信息关联

```sql
-- 视频基础信息 + 充电属性
SELECT 
  a.avid,
  a.title,
  a.up_id,
  a.uname,
  CASE WHEN b.avid IS NOT NULL THEN 1 ELSE 0 END AS is_charge
FROM b_dim.dim_ctnt_arch_business_tag_info_d a
LEFT JOIN b_dim.dim_ctnt_arch_charge_info_a_d b 
  ON a.avid = b.avid AND b.log_date = a.log_date
WHERE a.log_date = '20260414'
```

---

### 3. 播放数据关联订单数据

```sql
-- 播放到订单的完整链路
SELECT 
  p.mid,
  p.avid,
  SUM(p.vv) AS play_vv,
  SUM(o.order_amt) / 1000 AS gmv
FROM b_dwb.dwb_ctnt_arch_play_index_i_d p
LEFT JOIN bili_ogv.dwb_trd_main_chrg_order_p24h_ascrb_i_d o
  ON p.mid = o.mid 
  AND p.avid = o.avid
  AND o.log_date = p.log_date
  AND o.deduction_type = 2
WHERE p.log_date BETWEEN '20260301' AND '20260331'
GROUP BY p.mid, p.avid
```

---

## 版本历史

| 版本 | 日期 | 说明 |
|------|------|------|
| v1.0 | 2026-04-14 | 初始版本，基于2,824条历史SQL整理 |

---

**文档维护者**：数据分析团队  
**最后更新**：2026-04-14  

---

**使用提示**：
1. 本文档基于您的历史查询记录整理，包含最常用的表、指标和场景
2. 建议收藏备查，作为日常SQL编写参考
3. 如有疑问或需要补充，请随时反馈

---

📌 **复制完成后，建议保存为 `.md` 文件，使用 Markdown 阅读器查看效果最佳！**