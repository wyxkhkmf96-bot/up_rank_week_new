# 短带x 数据模型详细说明

来源：`raw/短带x数据查询指南.pdf`

本文是供 AI 写 SQL 时查阅的精炼版本，聚焦于：表的选用逻辑、核心字段含义、归因口径差异、常见坑点。

---

## 一、核心字段术语速查

| 字段名 | 含义 |
| :--- | :--- |
| `from_avid` | 种草视频的稿件 ID（UP 主发布的、带有付费内容跳转组件的 UGC 稿件） |
| `jump_type` | 组件类型（资源位），如关联视频、合集、story锚点、评论蓝链、空间页、框下 |
| `jump_text_id` | 种草视频挂载的付费内容的资源位对象 ID |
| `jump_text` | 资源位的文本描述 |
| `business_type` | 付费内容所在业务线（充电、OGV、课堂、短剧、短剧小程序等） |
| `sub_business_type` | 子业务线（例如充电下细分：漫剧、短剧） |
| `item_id_type` | 付费内容类型 |
| `item_id` | 付费内容 ID |
| `sourcefrom` | 用户进入小程序的渠道来源（可关联维表 `b_dim.dim_socl_short2x_playletminiapp_sourcefrom_info`） |
| `reportExtra` | 小程序埋点私参中携带的种草渠道参数，包含 `{from_avid; from_track_id}` |

---

## 二、推荐使用的事实表清单

### 2.1 核心推荐表（优先使用）

| 表名 | 用途 | 关键粒度 | 注意事项 |
| :--- | :--- | :--- | :--- |
| `b_dim.dim_ctnt_arch_basic_short_x_jump_content_view_a_hr` | 种草视频与跳转付费内容的映射关系（内容维表） | 种草稿件id + 业务类型 + 跳转类型 + 跳转目标id | 一个种草视频可对应多个业务/多个跳转目标 |
| `b_dim.dim_flow_short_x_show_click_hr` | 用户对种草视频挂载组件的曝光/点击行为 | 单次曝光/点击 | 覆盖：OGV/课堂/充电/收藏集/短剧小程序（含漫剧） |
| `b_dws.dws_socl_short2x_order_source_detail_info_1d_d` | **核心归因宽表**：订单归因给哪个种草稿件 | 归因类型（宽/窄）+ 订单id | **只含归因给种草稿件的订单，非全量收入**；覆盖充电/OGV/短剧小程序/课堂/收藏集；包含 IAA 和 IAP；包含窄口径和宽口径 |
| `b_dwb.dwb_socl_short2x_playletminiapp_user_behavior_detail_l_d` | 短剧小程序正片和广告曝光明细 | 单次曝光 | `goto='av'`=正片单集曝光；`goto='ad'`=广告曝光；ver881-884 正片曝光有缺失，由数仓兜底，用 `data_source` 区分 |
| `b_dwb.dwb_socl_short2x_playletminiapp_funnel_i_d` | 短剧小程序种草漏斗（含直接/间接归因 GMV） | 种草稿件id + 跳转类型 + 目标稿件id | `ad_gmv_direct` 可累加；`ad_gmv_indirect` 和 `ad_gmv` **不可直接累加**（`ad_gmv_indirect` 需按 `from_avid` 汇总取 `MAX`；`ad_gmv` 需按日期汇总取 `MAX`） |
| `iceberg_bdp.dwb_flow_abtest_group_split_l_1d_d` | AB 实验分流结果表 | `expr_id + group_id + splited_flow_id` | 仅适用于非算法实验；`splited_flow_id` 即为用户 `mid` |

### 2.2 充电专用归因表

| 表名 | 口径 | 说明 |
| :--- | :--- | :--- |
| `b_dwb.dwb_socl_short2x_charge_order_play_source_narrow_detail_i_d` | **充电 IAP 窄口径** | 查询种草视频带来的充电订单时推荐使用（替代直接查订单宽表） |
| `b_dwb.dwb_socl_short2x_charge_order_play_source_broad_detail_i_d` | **充电 IAP 宽口径** | 宽口径归因，窗口更宽松 |

### 2.3 其他可用表

| 表名 | 用途 | 备注 |
| :--- | :--- | :--- |
| `b_dwb.dwb_socl_short2x_short_miniapp_iaa_conversion_i_d` | 短剧小程序 IAA 付费模型 | 粒度：种草稿件id + 短剧小程序id |
| `b_dws.dws_socl_short2x_collection_card_from_av_lead_1d_d` | 收藏集种草漏斗 | 只含归因给种草的订单收入，非全量；`order_cnt`, `order_gmv` 可累加 |
| `r_sycpb.rt_attribution_iaa_program` | 小程序 IAA 收入明细（唯一数据源） | IAA 收入：`conv_type='inapp_charge' AND event='show'`；IAP 收入：`conv_type='user_cost'` 并对 `uk` 去重；`is_post_conversion_log='0'` 为自然流量，`='1'` 为商业流量 |
| `bili_sycpb.dwd_flow_req_pfmc_charge_comic_ad_attribution_l_d` | 充电 IAA 收入（商业侧自然归因结果） | 分渠道/天马/Story 等充电 IAA 归因底表 |
| `b_dwb.dwb_flow_funnel_order_attribution_i_d` | 充电投流漏斗-订单归因 | — |
| `b_dwb.dwb_flow_tm_trackid_show_click_play_i_d` | 天马展点播表 | 粒度：cid；常用于实验分析时天马渠道的 vv/ctr |

### 2.4 不推荐使用的表（标注了替代方案）

| 不推荐表 | 替代方案 |
| :--- | :--- |
| `b_dwb.dwb_socl_short2x_playletminiapp_funnel_i_d`（短剧小程序漏斗） | 查询种草收入时优先用 `b_dws.dws_socl_short2x_order_source_detail_info_1d_d` |
| `b_dwb.dwb_socl_short2x_novelminiapp_user_behavior_detail_l_d`（小说小程序漏斗） | 同上 |

---

## 三、各业务线归因口径详解

### 3.1 充电 IAP — 归因逻辑（窄口径）

**三链路归因，按优先级顺序执行：**

**A 链路（直接种草跳转归因）**：
1. 以充电订单出发，向前找用户对该充电 UP 主最近 1 次付费视频的观看记录
2. 以该观看时间点出发，向前找用户对该 UP 主最近 1 次种草视频观看记录
3. 校验用户是否存在从该种草视频跳转至付费视频的组件点击行为

**B 链路（空间页跳转归因）**：
1. 以 A 链路未归因订单出发，找用户该 UP 主最近 1 次播放来源是空间页跳转的付费视频播放记录
2. 以该观看时间点出发，找用户对该 UP 主最近 1 次免费视频播放记录

**C 链路（兜底归因）**：
1. 以 B 链路未归因订单出发，找用户对该 UP 主最近 1 次免费视频播放记录

**校验要求（所有链路）**：
- 行为时间顺序：种草视频观看 < 组件点击 < 付费视频观看 < 订单创建
- 时间窗口：种草视频观看时间与订单创建时间在 **24 小时之内**

**宽口径** 与窄口径的核心差异：不要求组件点击行为验证，只需行为时间顺序正确，取距离付费视频观看最近的来源视频。

### 3.2 充电 IAA — 归因逻辑

分三层归因，顺序执行：

1. **直接渠道归因**：本次付费视频播放场景是 UGC/Story 播放页的订单，按 `from_spmid`、`playpage_trackid` 拆分渠道（story 直接分发、天马直接分发、相关推荐直接分发、搜索直接分发）
2. **种草视频转化归因**：未被直接渠道归因的订单，寻找用户最近 1 次的种草视频组件跳转点击；需存在种草视频播放记录
3. **空间页转化归因**：前两步未归因的订单，若付费视频播放来自空间页，找用户对该 UP 主最近 1 次免费视频观看

数据来源表：`bili_sycpb.dwd_flow_req_pfmc_charge_comic_ad_attribution_l_d`

### 3.3 短剧小程序广告曝光 — 直接/间接归属

| 归属类型 | 前提条件 | 逻辑 |
| :--- | :--- | :--- |
| **直接归属**（`ad_gmv_direct`） | 埋点私参 `reportExtra` 中有 `from_avid` 上报 | 直接将本次广告收益归属给该 `from_avid` |
| **间接归属**（`ad_gmv_indirect`） | 埋点有 `episode_id` 上报 | 根据 `episode_id` 匹配种草内容维表，再关联播放记录，取距曝光最近的种草视频播放记录 |

⚠️ **`ad_gmv_indirect` 不可直接 SUM**：需按 `from_avid` 汇总后取 `MAX`，否则会重复计算。

### 3.4 收藏集 IAP — 归因逻辑

1. **直接归因**：订单创建成功埋点的 `from_av` 私参直接指定来源种草视频
2. **间接归因**：直接归因失败时，找用户最近 1 次对有该收藏集挂载的种草视频观看记录

注意：间接归因**不要求**组件点击行为。

### 3.5 小说/短剧小程序 IAA — 归因逻辑

埋点私参 `reportExtra` 中上报 `request_id` 和 `from_avid`，将曝光埋点的 `request_id` 与订单表 `request_id` 关联。

关键筛选条件：
- `event_id = 'miniapp.window.request-video-ad.0.show'`
- 广告实际曝光：`ad_ready = 4`
- 剔除兜底广告：`ad_is_fake != 1`（兜底广告的 `request_id` 会重复使用上次成功请求的 id，不产生扣费）

### 3.6 课堂 IAP / OGV IAP

归因口径分别由课堂数仓侧（`bi_chunhua.dws_trad_ecommerce_attribution_l_d`）和 OGV 数仓侧（`bili_ogv.ads_ogv_rpt_zhongcao_conv_order_base_dtl_1d_d`）维护，短带数仓仅做种草视频播放的校验。

---

## 四、维度表与 UP 主名单

### 4.1 UP 主行业归属名单（注意区分短剧与漫剧）

| 行业 | 表名 | 使用方式 | 说明 |
| :--- | :--- | :--- | :--- |
| 短剧（真人短剧） | `b_dim.dim_socl_elec_basic_up_info` | 无日期分区，直接取全量 | 可用于 UP 行业归属判断 |
| 漫剧（动画短剧） | `bi_ogv.dim_ai_donghua_up_list` | 取已有 `log_date` 最新一天 | 可用于 UP 行业归属判断 |
| 漫剧补充 | `bili_main.dim_ai_donghua_up_list_supple` | 无日期分区，直接取全量 | **不可用于 UP 行业归属判断**，仅用于快速将 UP 加入算法模型 |
| 漫剧种草结算 | `b_dim.dim_socl_short2x_donghuaduanju_zhongcao_up_list` | 无日期分区，直接取全量 | **不可用于 UP 行业归属判断**，维护漫剧种草 UP 和机构的关系，用于区分个人/机构结算方案 |

⚠️ **短剧和漫剧由不同人员维护，两侧名单可能出现重复**，如有需要去重的场景需联系数据产品评估。

### 4.2 其他常用维表

| 表名 | 用途 |
| :--- | :--- |
| `b_dim.dim_socl_short2x_playletminiapp_sourcefrom_info` | `sourcefrom` 字段解码维表（渠道来源中文名映射） |
| `b_dim.dim_socl_short2x_open_mallapp_mini_app_cat_d` | 小程序 `app_id` 维表 |
| `b_ods.ods_bili2_platform_t_episode_base_a_hr` | 小程序单片维表（`episode_id`） |
| `b_ods.ods_bili_platform_t_season_base_a_hr` | 小程序剧集维表（`season_id`） |
| `bi_sycpb.dwd_miniapp_season_authorization_a_hr` | 小程序单片与 `appid` + `season_id` 映射 |
| `b_dim.dim_socl_elec_arch_miniapp_avid_record_a_d` | 漫剧小程序单片与原始稿件映射（`aid` 为小程序单片稿件 `avid`） |
| `b_dim.dim_flow_story_short_x_d` | story 相关搜索：种草视频与对应跳转搜索词的匹配 |

---

## 五、关键坑点汇总

1. **`ad_gmv_indirect` 不可直接 SUM**：需按 `from_avid` 汇总后取 `MAX`；`ad_gmv`（直接+间接合计）同样需要按日期取 `MAX`
2. **漫剧名单不能混用短剧名单**：两张表互相独立，不互通
3. **`dim_ai_donghua_up_list` 不是每天更新**：取最新分区用 `SELECT MAX(log_date) FROM ...`
4. **短剧小程序 ver881-884 正片曝光有缺失**：数仓有兜底，用 `data_source` 字段区分
5. **充电 IAP 归因表要用专用表**：`dws_socl_short2x_order_source_detail_info_1d_d` 只含归因给种草的订单，如果需要全量充电订单用 `b_dwb.dwb_trad_ord_elec_order_detail_info_i_d`
